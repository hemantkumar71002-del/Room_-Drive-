# Room Drive App: Backend

Node.js + Express + SQLite + Socket.IO + Google Drive.

## Setup

1. Install Node.js 20 or newer, then run `npm install`.
2. Copy `.env.example` to `.env` and fill it in (instructions are inside the file).
3. In Google Cloud Console:
   - Create a project and enable the **Google Drive API**.
   - Configure the OAuth consent screen. While it is in "Testing" mode, add your admin Google accounts as test users.
   - Create an **OAuth client ID** of type *Web application* and add `http://localhost:3000/api/drive/callback` as an authorized redirect URI.
   - Copy the client ID and secret into `.env`.
4. Run `npm start`. The server listens on port 3000.

`public/index.html` is the app page (served at `/`), with styles in `public/css/` and scripts in `public/js/`. Backend code is split into `src/` (config, db, auth, realtime, `routes/`, `services/`); `server.js` only wires them together. The backup script is `scripts/backup.js`.

## API

| Method | Path | Who | Purpose |
|---|---|---|---|
| POST | `/api/admin/register` | public | Create admin (`name`, `password`) |
| POST | `/api/admin/login` | public | Admin login, returns token |
| GET / POST | `/api/admin/viewers` | admin | List / create viewers (`username`, `password`, `role`) |
| DELETE | `/api/admin/viewers/:id` | admin | Remove viewer and log the device out |
| POST | `/api/admin/viewers/:id/force-logout` | admin | Free the device |
| POST | `/api/admin/viewers/:id/reset-password` | admin | Set a new password (`password`) |
| POST | `/api/user/login` | public | User login (`username`, `password`, `deviceId`) |
| POST | `/api/user/logout` | user | Log out and free the device |
| GET | `/api/drive/connect` | admin | Returns the Google sign-in URL |
| POST | `/api/drive/disconnect` | admin | Remove the stored Drive token |
| GET | `/api/files` | admin, user | List files |
| POST | `/api/files` | admin, uploader | Upload (multipart field `file`) |
| GET | `/api/files/:id/download` | admin, user | Stream the file from Drive |
| DELETE | `/api/files/:id` | admin | Delete the file |

Send the token as `Authorization: Bearer <token>`.

## Realtime

Connect with `io({ auth: { token } })`. The server emits:

- `files:update` with the full file list after every upload or delete
- `force-logout` when the admin removes the viewer, forces a logout, or resets the password

## How the one-device rule works

On login the server stores a `session_id` and the `deviceId` the client sent. A login from a different `deviceId` is rejected until the user logs out or the admin uses Force logout. The `deviceId` should be a random value that the browser generates once and keeps in `localStorage`. Every request and socket connection is checked against the stored `session_id`, so removal takes effect immediately.

## Before going live

- Serve everything over HTTPS.
- Use strong, unique values for `JWT_SECRET` and `ENCRYPTION_KEY`, and never commit `.env`.
- Back up `app.db`. Losing `ENCRYPTION_KEY` means every admin must reconnect Drive.
- While the Google consent screen is in "Testing", only your test users can connect and the Drive token expires after 7 days. Publish the app ("In production") for normal use. The app only asks for the non-sensitive `drive.file` scope, which needs basic verification only. See GUIDE.md.

## Document preview (DOC, DOCX, PPTX)

`GET /api/files/:id/preview` converts the file to PDF with LibreOffice and caches it in `PREVIEW_DIR`. If LibreOffice is not installed the server answers 501 and the app falls back to a normal download.

- Install LibreOffice (`soffice`) on your computer or server, or deploy with the included `Dockerfile`, which installs it.
- If `soffice` is not on the PATH, set `SOFFICE_PATH` in `.env`.
- The first open of a file takes a few seconds; later opens are instant.

## Backups

`npm run backup` saves a copy of the database into `BACKUP_DIR` and keeps the newest `BACKUP_KEEP` copies. Schedule it daily and also copy the backups off the server. Store `ENCRYPTION_KEY` separately.

## Google sign-in endpoints (available, not used by the current screens)

`GET /api/auth/google/start` returns a Google sign-in URL (scopes: openid, email, profile, drive.file). Google's own page asks for the email and password, so this app never sees them. The same redirect URI as Drive is used (`/api/drive/callback`); it creates the admin on first sign-in, connects Drive in the same step, and sends the browser back to `/?gauth=<one-time code>`, which the app swaps for a token with `POST /api/auth/google/exchange`. Google admins have no app password. Add `openid`, `email` and `profile` on the OAuth consent screen (all non-sensitive).

`GET /api/drive/connect?email=name@gmail.com` adds `login_hint`, so Google's sign-in page opens with that email already filled in. The password is always typed on Google's own page.

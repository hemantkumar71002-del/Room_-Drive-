# Room Drive backend

Node.js + Express + SQLite + socket.io. Files are stored in Supabase Storage (free, no card).

## Environment variables
| Name | Purpose |
|---|---|
| `JWT_SECRET` | Long random string, signs login tokens (required) |
| `SUPABASE_URL` | Your Supabase project URL |
| `SUPABASE_SERVICE_KEY` | Supabase secret key (server only, never share) |
| `SUPABASE_BUCKET` | Bucket name (default `room-drive`, created automatically) |
| `ACCESS_CODE` | Shared password the app asks for on opening. Empty = open to all |
| `OWNER_PASSWORD` | Owner panel password (control all admins and users). Empty = panel off |
| `TRUST_PROXY` | `1` when running behind Render or another proxy |

## Run
```
npm install
node server.js
```
The database is backed up to Supabase every 30 seconds and restored on start, so data survives free-tier restarts.

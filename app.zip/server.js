const express = require('express');
const http = require('http');
const path = require('path');
const multer = require('multer');
const helmet = require('helmet');
const cors = require('cors');
const { PORT, PUBLIC_DIR } = require('./src/config');
const { initRealtime } = require('./src/realtime');

const app = express();
const server = http.createServer(app);
initRealtime(server);

if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY) || 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors()); // APK (alag origin) se API calls ke liye. Auth Bearer token se hoti hai, cookies nahi.
app.use(express.json());

// index.html (the app page) and all other assets are served from public/
app.get(['/', '/index.html'], (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));
app.use(express.static(PUBLIC_DIR, { index: false }));

app.use(require('./src/routes/admin'));
app.use(require('./src/routes/viewers'));
app.use(require('./src/routes/user'));
app.use(require('./src/routes/google'));
app.use(require('./src/routes/files'));

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'The file is larger than 25 MB.' : err.message });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong.' });
});

server.listen(PORT, () => console.log('Server running on http://localhost:' + PORT));

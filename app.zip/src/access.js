const crypto = require('crypto');
const CODE = process.env.ACCESS_CODE || '';
const same = (a, b) => {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
};
const ok = (c) => !CODE || same(c || '', CODE);

// wrong-code attempts: 10 per 15 min per IP
const tries = new Map();
function limited(ip) {
  const now = Date.now(), t = tries.get(ip);
  if (!t || now - t.at > 15 * 60 * 1000) return false;
  return t.n >= 10;
}
function miss(ip) {
  const now = Date.now(), t = tries.get(ip);
  if (!t || now - t.at > 15 * 60 * 1000) tries.set(ip, { n: 1, at: now });
  else t.n++;
}

// POST /api/access-check  { code }  -> { ok, required }
function check(req, res) {
  const ip = req.ip;
  if (!CODE) return res.json({ ok: true, required: false });
  if (limited(ip)) return res.status(429).json({ ok: false, required: true, error: 'Too many wrong attempts. Try again in 15 minutes.' });
  const good = ok((req.body || {}).code);
  if (!good) miss(ip);
  res.status(good ? 200 : 401).json({ ok: good, required: true, error: good ? undefined : 'Wrong access password.' });
}

// middleware for every other /api route
function gate(req, res, next) {
  if (ok(req.get('x-access-code'))) return next();
  res.status(403).json({ error: 'Access password required.', access: true });
}
const socketOk = (socket) => ok(socket.handshake.auth && socket.handshake.auth.code);
module.exports = { check, gate, socketOk, enabled: !!CODE };

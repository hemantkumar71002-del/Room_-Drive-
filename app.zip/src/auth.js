const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { JWT_SECRET } = require('./config');
const { db } = require('./db');

// Checks a token and, for viewers, that the account is active and the session is the current one.
function verify(token) {
  const p = jwt.verify(token, JWT_SECRET);
  if (p.type === 'admin') {
    const ad = db.prepare('SELECT blocked FROM admins WHERE id = ?').get(p.id);
    if (!ad || ad.blocked) throw new Error('gone');
    return { type: 'admin', adminId: p.id };
  }
  const v = db.prepare('SELECT * FROM viewers WHERE id = ?').get(p.id);
  if (!v || v.status !== 'active' || v.session_id !== p.sid) throw new Error('ended');
  const own = db.prepare('SELECT blocked FROM admins WHERE id = ?').get(v.admin_id);
  if (!own || own.blocked) throw new Error('ended');
  return { type: 'user', adminId: v.admin_id, viewer: v };
}
function auth(...roles) {
  return (req, res, next) => {
    try {
      const ctx = verify((req.headers.authorization || '').replace('Bearer ', ''));
      if (!roles.includes(ctx.type)) return res.status(403).json({ error: 'Not allowed.' });
      Object.assign(req, ctx);
      next();
    } catch {
      res.status(401).json({ error: 'Session ended. Please log in again.' });
    }
  };
}
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, skipSuccessfulRequests: true, message: { error: 'Too many attempts. Please try again later.' } });

module.exports = { verify, auth, loginLimiter };

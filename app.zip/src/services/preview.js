// DOC / DOCX / PPTX preview (converted to PDF with LibreOffice)
const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');
const { execFile } = require('child_process');
const { PREVIEW_DIR, SOFFICE } = require('../config');

const LO_PROFILE = pathToFileURL(path.join(os.tmpdir(), 'rda-lo-profile')).href;
const PREVIEWABLE = ['doc', 'docx', 'pptx'];
fs.mkdirSync(PREVIEW_DIR, { recursive: true });
const previewPath = (f) => path.join(PREVIEW_DIR, f.id + '-' + f.drive_file_id + '.pdf');
const converting = new Map();
let queue = Promise.resolve(); // LibreOffice converts one file at a time

function runSoffice(args) {
  return new Promise((resolve, reject) =>
    execFile(SOFFICE, args, { timeout: 90000 }, (err) => {
      if (!err) return resolve();
      if (err.code === 'ENOENT') err.noOffice = true;
      reject(err);
    })
  );
}
function convertToPdf(f, d) {
  const out = previewPath(f);
  if (fs.existsSync(out)) return Promise.resolve(out);
  if (converting.has(out)) return converting.get(out);
  const job = queue.then(async () => {
    if (fs.existsSync(out)) return out;
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'prev-'));
    try {
      const src = path.join(tmp, 'source.' + f.ext);
      const r = await d.drive.files.get({ fileId: f.drive_file_id, alt: 'media' }, { responseType: 'stream' });
      await new Promise((ok, bad) => {
        const w = fs.createWriteStream(src);
        r.data.on('error', bad);
        w.on('error', bad);
        w.on('finish', ok);
        r.data.pipe(w);
      });
      await runSoffice(['--headless', '--norestore', '-env:UserInstallation=' + LO_PROFILE, '--convert-to', 'pdf', '--outdir', tmp, src]);
      fs.copyFileSync(path.join(tmp, 'source.pdf'), out);
      return out;
    } finally {
      fs.rmSync(tmp, { recursive: true, force: true });
    }
  });
  queue = job.catch(() => {});
  converting.set(out, job);
  job.then(() => converting.delete(out), () => converting.delete(out));
  return job;
}
module.exports = { PREVIEWABLE, previewPath, convertToPdf };

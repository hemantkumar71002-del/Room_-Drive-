// File storage: Supabase Storage (free, no card).
const crypto = require('crypto');
const { Readable } = require('stream');

const SB = (process.env.SUPABASE_URL || '').replace(/\/+$/, '');
const KEY = process.env.SUPABASE_SERVICE_KEY || '';
const BUCKET = process.env.SUPABASE_BUCKET || 'room-drive';
const enabled = !!SB;

const auth = () => ({ Authorization: 'Bearer ' + KEY, apikey: KEY });
const enc = (k) => k.split('/').map(encodeURIComponent).join('/');
const writeUrl = (k) => SB + '/storage/v1/object/' + BUCKET + '/' + enc(k);
const readUrl = (k) => SB + '/storage/v1/object/authenticated/' + BUCKET + '/' + enc(k);

async function ensureBucket() {
  if (!enabled) return;
  const r = await fetch(SB + '/storage/v1/bucket', {
    method: 'POST',
    headers: { ...auth(), 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: BUCKET, name: BUCKET, public: false }),
  });
  if (!r.ok && r.status !== 400 && r.status !== 409) console.error('Supabase bucket check failed: ' + r.status + ' ' + (await r.text()));
}
async function putRaw(key, buffer, type) {
  const r = await fetch(writeUrl(key), {
    method: 'POST',
    headers: { ...auth(), 'Content-Type': type || 'application/octet-stream', 'x-upsert': 'true' },
    body: buffer,
  });
  if (!r.ok) throw new Error('Supabase upload failed: ' + r.status + ' ' + (await r.text()));
}
async function getRaw(key) {
  const r = await fetch(readUrl(key), { headers: auth() });
  if (r.status === 404 || r.status === 400) return null;
  if (!r.ok) throw new Error('Supabase download failed: ' + r.status);
  return r;
}

// Is the storage backend configured?
async function ready() {
  return enabled;
}
// Saves an uploaded file (multer file). Returns the id to keep in the database.
async function put(adminId, f) {
  const key = adminId + '/' + crypto.randomBytes(12).toString('hex');
  await putRaw(key, f.buffer, f.mimetype);
  return key;
}
async function stream(adminId, id) {
  const r = await getRaw(id);
  if (!r) throw new Error('File not found in storage');
  return Readable.fromWeb(r.body);
}
async function remove(adminId, id) {
  if (!enabled) return;
  await fetch(writeUrl(id), { method: 'DELETE', headers: auth() }).catch(() => {});
}
module.exports = { enabled, ensureBucket, putRaw, getRaw, ready, put, stream, remove };

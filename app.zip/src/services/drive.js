const { google } = require('googleapis');
const { db } = require('../db');
const { dec } = require('../crypto');

const oauthClient = () =>
  new google.auth.OAuth2(process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET, process.env.GOOGLE_REDIRECT_URI);

async function driveFor(adminId) {
  const a = db.prepare('SELECT * FROM admins WHERE id = ?').get(adminId);
  if (!a || !a.drive_token) return null;
  const c = oauthClient();
  c.setCredentials({ refresh_token: dec(a.drive_token) });
  const drive = google.drive({ version: 'v3', auth: c });
  let folder = a.drive_folder;
  if (!folder) {
    const r = await drive.files.create({ requestBody: { name: 'Room Drive App', mimeType: 'application/vnd.google-apps.folder' }, fields: 'id' });
    folder = r.data.id;
    db.prepare('UPDATE admins SET drive_folder = ? WHERE id = ?').run(folder, adminId);
  }
  return { drive, folder };
}
module.exports = { oauthClient, driveFor };

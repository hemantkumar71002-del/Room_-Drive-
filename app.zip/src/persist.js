// Keeps the SQLite database alive across restarts on hosts without a disk (e.g. Render free).
// The database is copied to Supabase Storage regularly, and restored when the server starts.
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { DB_PATH } = require('./config');
const store = require('./services/store');

const KEYNAME = '_backup/app.db';
let lastHash = '';
let busy = false;

async function restoreDb() {
  if (!store.enabled) return;
  try {
    await store.ensureBucket();
    if (fs.existsSync(DB_PATH)) return;
    const r = await store.getRaw(KEYNAME);
    if (!r) return console.log('No saved database found. Starting fresh.');
    fs.mkdirSync(path.dirname(path.resolve(DB_PATH)), { recursive: true });
    fs.writeFileSync(DB_PATH, Buffer.from(await r.arrayBuffer()));
    console.log('Database restored from storage.');
  } catch (e) {
    console.error('Database restore failed: ' + e.message);
  }
}
async function syncNow() {
  if (!store.enabled || busy) return;
  busy = true;
  const tmp = path.join(os.tmpdir(), 'rda-db-' + process.pid + '.db');
  try {
    const { db } = require('./db');
    await db.backup(tmp);
    const buf = fs.readFileSync(tmp);
    const h = crypto.createHash('md5').update(buf).digest('hex');
    if (h !== lastHash) {
      await store.putRaw(KEYNAME, buf, 'application/octet-stream');
      lastHash = h;
    }
  } catch (e) {
    console.error('Database sync failed: ' + e.message);
  } finally {
    fs.rmSync(tmp, { force: true });
    busy = false;
  }
}
function startSync() {
  if (!store.enabled) return;
  setTimeout(syncNow, 5000);
  setInterval(syncNow, 30000);
  const bye = () => { busy = false; syncNow().finally(() => process.exit(0)); };
  process.on('SIGTERM', bye);
  process.on('SIGINT', bye);
}
module.exports = { restoreDb, startSync, syncNow };

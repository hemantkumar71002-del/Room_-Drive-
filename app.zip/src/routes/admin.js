const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config');
const { db, nameTaken, getSetting } = require('../db');
const { auth, loginLimiter } = require('../auth');

const router = express.Router();

router.get('/api/signup-status', (req, res) => res.json({ open: getSetting('signup', 'open') === 'open' }));
router.post('/api/admin/register', loginLimiter, (req, res) => {
  if (getSetting('signup', 'open') !== 'open') return res.status(403).json({ error: 'New admin IDs are closed. Please contact the owner.' });
  const name = String((req.body || {}).name || '').trim();
  const password = String((req.body || {}).password || '');
  if (!name || password.length < 6) return res.status(400).json({ error: 'A name and a password of at least 6 characters are required.' });
  if (nameTaken(name)) return res.status(409).json({ error: 'This admin name is already taken.' });
  db.prepare('INSERT INTO admins (name, pass_hash) VALUES (?, ?)').run(name, bcrypt.hashSync(password, 12));
  res.json({ ok: true });
});
router.post('/api/admin/login', loginLimiter, (req, res) => {
  const { name, password } = req.body || {};
  const a = db.prepare('SELECT * FROM admins WHERE name = ?').get(String(name || ''));
  if (!a || !bcrypt.compareSync(String(password || ''), a.pass_hash)) return res.status(401).json({ error: 'Incorrect admin name or password.' });
  if (a.blocked) return res.status(403).json({ error: 'This admin account is blocked. Please contact the owner.' });
  const token = jwt.sign({ type: 'admin', id: a.id }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, name: a.name });
});
router.get('/api/admin/me', auth('admin'), (req, res) => {
  const a = db.prepare('SELECT name FROM admins WHERE id = ?').get(req.adminId);
  res.json({ name: a.name });
});

module.exports = router;

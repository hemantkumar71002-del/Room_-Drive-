const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config');
const { db, nameTaken } = require('../db');
const { auth, loginLimiter } = require('../auth');

const router = express.Router();

router.post('/api/admin/register', loginLimiter, (req, res) => {
  const name = String((req.body || {}).name || '').trim();
  const password = String((req.body || {}).password || '');
  if (!name || password.length < 6) return res.status(400).json({ error: 'A name and a password of at least 6 characters are required.' });
  if (nameTaken(name)) return res.status(409).json({ error: 'This admin name is already taken.' });
  db.prepare('INSERT INTO admins (name, pass_hash) VALUES (?, ?)').run(name, bcrypt.hashSync(password, 12));
  res.json({ ok: true });
});
router.post('/api/admin/login', loginLimiter, (req, res) => {
  const { name, password } = req.body || {};
  const a = db.prepare('SELECT * FROM admins WHERE name = ?').get(String(name || ''));
  if (!a || !bcrypt.compareSync(String(password || ''), a.pass_hash)) return res.status(401).json({ error: 'Incorrect admin name or password.' });
  const token = jwt.sign({ type: 'admin', id: a.id }, JWT_SECRET, { expiresIn: '8h' });
  res.json({ token, name: a.name, driveConnected: !!a.drive_token });
});
router.get('/api/admin/me', auth('admin'), (req, res) => {
  const a = db.prepare('SELECT name, drive_token FROM admins WHERE id = ?').get(req.adminId);
  res.json({ name: a.name, driveConnected: !!a.drive_token });
});

module.exports = router;

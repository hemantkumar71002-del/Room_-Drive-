// User (viewer) login: one ID, one device
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config');
const { db } = require('../db');
const { auth, loginLimiter } = require('../auth');
const { kickViewer } = require('../realtime');

const router = express.Router();

router.post('/api/user/login', loginLimiter, (req, res) => {
  const { username, password, deviceId } = req.body || {};
  if (!username || !password || !deviceId) return res.status(400).json({ error: 'User ID, password and deviceId are required.' });
  const v = db.prepare('SELECT * FROM viewers WHERE username = ?').get(String(username));
  if (!v || v.status !== 'active' || !bcrypt.compareSync(String(password), v.pass_hash)) {
    return res.status(401).json({ error: 'Incorrect user ID or password.' });
  }
  if (v.session_id && v.device_id !== String(deviceId)) {
    return res.status(409).json({ error: 'This ID is already in use on another device. Please log out there first, or contact the admin.' });
  }
  const sid = crypto.randomUUID();
  db.prepare('UPDATE viewers SET session_id = ?, device_id = ? WHERE id = ?').run(sid, String(deviceId), v.id);
  const token = jwt.sign({ type: 'user', id: v.id, sid }, JWT_SECRET, { expiresIn: '1h' });
  res.json({ token, username: v.username, role: v.role });
});
router.post('/api/user/logout', auth('user'), (req, res) => {
  kickViewer(req.viewer.id);
  res.json({ ok: true });
});

module.exports = router;

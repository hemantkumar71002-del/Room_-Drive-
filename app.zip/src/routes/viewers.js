// Viewers (managed by admin)
const express = require('express');
const bcrypt = require('bcryptjs');
const { db, nameTaken } = require('../db');
const { auth } = require('../auth');
const { kickViewer } = require('../realtime');

const router = express.Router();

router.get('/api/admin/viewers', auth('admin'), (req, res) => {
  res.json(db.prepare('SELECT id, username, role, (session_id IS NOT NULL) AS online FROM viewers WHERE admin_id = ?').all(req.adminId));
});
router.post('/api/admin/viewers', auth('admin'), (req, res) => {
  const username = String((req.body || {}).username || '').trim();
  const password = String((req.body || {}).password || '');
  const role = (req.body || {}).role === 'uploader' ? 'uploader' : 'viewer';
  if (!username || password.length < 6) return res.status(400).json({ error: 'A username and a password of at least 6 characters are required.' });
  if (nameTaken(username)) return res.status(409).json({ error: 'This ID is already taken.' });
  db.prepare('INSERT INTO viewers (admin_id, username, pass_hash, role) VALUES (?, ?, ?, ?)').run(req.adminId, username, bcrypt.hashSync(password, 12), role);
  res.json({ ok: true });
});
function ownViewer(req, res) {
  const v = db.prepare('SELECT * FROM viewers WHERE id = ? AND admin_id = ?').get(req.params.id, req.adminId);
  if (!v) res.status(404).json({ error: 'Viewer not found.' });
  return v;
}
router.delete('/api/admin/viewers/:id', auth('admin'), (req, res) => {
  const v = ownViewer(req, res); if (!v) return;
  kickViewer(v.id);
  db.prepare('DELETE FROM viewers WHERE id = ?').run(v.id);
  res.json({ ok: true });
});
router.post('/api/admin/viewers/:id/force-logout', auth('admin'), (req, res) => {
  const v = ownViewer(req, res); if (!v) return;
  kickViewer(v.id);
  res.json({ ok: true });
});
router.post('/api/admin/viewers/:id/reset-password', auth('admin'), (req, res) => {
  const v = ownViewer(req, res); if (!v) return;
  const password = String((req.body || {}).password || '');
  if (password.length < 6) return res.status(400).json({ error: 'The password must contain at least 6 characters.' });
  db.prepare('UPDATE viewers SET pass_hash = ? WHERE id = ?').run(bcrypt.hashSync(password, 12), v.id);
  kickViewer(v.id);
  res.json({ ok: true });
});

module.exports = router;

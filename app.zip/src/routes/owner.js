// Owner panel: ek OWNER_PASSWORD se saare admin / user accounts ka control
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config');
const { db, getSetting, setSetting } = require('../db');
const { loginLimiter } = require('../auth');
const { kickViewer, broadcast } = require('../realtime');
const store = require('../services/store');

const router = express.Router();
const OWNER = process.env.OWNER_PASSWORD || '';
const same = (a, b) => crypto.timingSafeEqual(crypto.createHash('sha256').update(String(a)).digest(), crypto.createHash('sha256').update(String(b)).digest());

router.post('/api/owner/login', loginLimiter, (req, res) => {
  if (!OWNER) return res.status(403).json({ error: 'Owner access is not set up on the server.' });
  if (!same((req.body || {}).password || '', OWNER)) return res.status(401).json({ error: 'Incorrect owner password.' });
  res.json({ token: jwt.sign({ type: 'owner' }, JWT_SECRET, { expiresIn: '2h' }) });
});

function owner(req, res, next) {
  try {
    const p = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), JWT_SECRET);
    if (p.type !== 'owner' || !OWNER) throw new Error('no');
    next();
  } catch { res.status(401).json({ error: 'Owner session ended. Please log in again.' }); }
}
const pw = (req, res) => {
  const p = String((req.body || {}).password || '');
  if (p.length < 6) { res.status(400).json({ error: 'The password must contain at least 6 characters.' }); return null; }
  return bcrypt.hashSync(p, 12);
};
const kickAll = (adminId) => db.prepare('SELECT id FROM viewers WHERE admin_id = ?').all(adminId).forEach((v) => kickViewer(v.id));

router.get('/api/owner/overview', owner, (req, res) => {
  const admins = db.prepare(`SELECT a.id, a.name, a.blocked,
    (SELECT COUNT(*) FROM viewers v WHERE v.admin_id = a.id) AS viewers,
    (SELECT COUNT(*) FROM files f WHERE f.admin_id = a.id) AS files,
    (SELECT COALESCE(SUM(size), 0) FROM files f WHERE f.admin_id = a.id) AS bytes
    FROM admins a ORDER BY a.id`).all();
  res.json({ admins, signupOpen: getSetting('signup', 'open') === 'open' });
});
router.post('/api/owner/signup', owner, (req, res) => {
  setSetting('signup', (req.body || {}).open ? 'open' : 'closed');
  res.json({ ok: true });
});
router.get('/api/owner/admins/:id/viewers', owner, (req, res) => {
  res.json(db.prepare('SELECT id, username, role, (session_id IS NOT NULL) AS online FROM viewers WHERE admin_id = ?').all(req.params.id));
});
router.post('/api/owner/admins/:id/reset-password', owner, (req, res) => {
  const h = pw(req, res); if (!h) return;
  db.prepare('UPDATE admins SET pass_hash = ? WHERE id = ?').run(h, req.params.id);
  res.json({ ok: true });
});
router.post('/api/owner/admins/:id/block', owner, (req, res) => {
  const b = (req.body || {}).blocked ? 1 : 0;
  db.prepare('UPDATE admins SET blocked = ? WHERE id = ?').run(b, req.params.id);
  if (b) kickAll(req.params.id);
  res.json({ ok: true });
});
router.delete('/api/owner/admins/:id', owner, async (req, res) => {
  const id = Number(req.params.id);
  if (!db.prepare('SELECT 1 FROM admins WHERE id = ?').get(id)) return res.status(404).json({ error: 'Admin not found.' });
  kickAll(id);
  for (const f of db.prepare('SELECT drive_file_id FROM files WHERE admin_id = ?').all(id)) {
    try { await store.remove(id, f.drive_file_id); } catch (e) { console.error(e.message); }
  }
  db.prepare('DELETE FROM files WHERE admin_id = ?').run(id);
  db.prepare('DELETE FROM viewers WHERE admin_id = ?').run(id);
  db.prepare('DELETE FROM admins WHERE id = ?').run(id);
  res.json({ ok: true });
});
router.post('/api/owner/viewers/:id/force-logout', owner, (req, res) => { kickViewer(Number(req.params.id)); res.json({ ok: true }); });
router.post('/api/owner/viewers/:id/reset-password', owner, (req, res) => {
  const h = pw(req, res); if (!h) return;
  db.prepare('UPDATE viewers SET pass_hash = ? WHERE id = ?').run(h, req.params.id);
  kickViewer(Number(req.params.id));
  res.json({ ok: true });
});
router.delete('/api/owner/viewers/:id', owner, (req, res) => {
  kickViewer(Number(req.params.id));
  db.prepare('DELETE FROM viewers WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;

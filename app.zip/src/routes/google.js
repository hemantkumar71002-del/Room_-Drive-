// Google Drive connect + sign in / sign up with Google
const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config');
const { db, nameTaken } = require('../db');
const { enc } = require('../crypto');
const { auth } = require('../auth');
const { oauthClient } = require('../services/drive');

const router = express.Router();

router.get('/api/drive/connect', auth('admin'), (req, res) => {
  const state = jwt.sign({ id: req.adminId }, JWT_SECRET, { expiresIn: '10m' });
  const hint = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(req.query.email || '')) ? String(req.query.email) : '';
  const url = oauthClient().generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: ['https://www.googleapis.com/auth/drive.file'],
    state,
    ...(hint ? { login_hint: hint } : {}),
  });
  res.json({ url });
});

const gCodes = new Map(); // one-time codes (valid 60 s) that hand the app token to the browser after Google sign-in
router.get('/api/auth/google/start', (req, res) => {
  if (!process.env.GOOGLE_CLIENT_ID) return res.status(501).json({ error: 'Google sign-in is not set up on this server yet.' });
  const state = jwt.sign({ g: 1 }, JWT_SECRET, { expiresIn: '10m' });
  const url = oauthClient().generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: ['openid', 'email', 'profile', 'https://www.googleapis.com/auth/drive.file'],
    state,
  });
  res.json({ url });
});
router.post('/api/auth/google/exchange', (req, res) => {
  const code = String((req.body || {}).code || '');
  const e = gCodes.get(code);
  gCodes.delete(code);
  if (!e || e.exp < Date.now()) return res.status(400).json({ error: 'The Google sign-in expired. Please try again.' });
  res.json(e.data);
});
async function googleSignIn(tokens) {
  const ticket = await oauthClient().verifyIdToken({ idToken: tokens.id_token, audience: process.env.GOOGLE_CLIENT_ID });
  const p = ticket.getPayload();
  if (!p.email_verified) throw new Error('unverified');
  let a = db.prepare('SELECT * FROM admins WHERE google_sub = ?').get(p.sub);
  if (!a) {
    let name = p.email;
    for (let i = 2; nameTaken(name); i++) name = p.email + ' (' + i + ')';
    const id = db.prepare('INSERT INTO admins (name, pass_hash, google_sub, email) VALUES (?, ?, ?, ?)')
      .run(name, bcrypt.hashSync(crypto.randomBytes(32).toString('hex'), 12), p.sub, p.email).lastInsertRowid;
    a = db.prepare('SELECT * FROM admins WHERE id = ?').get(id);
  }
  if (tokens.refresh_token) {
    db.prepare('UPDATE admins SET drive_token = ?' + (a.drive_token ? '' : ', drive_folder = NULL') + ' WHERE id = ?').run(enc(tokens.refresh_token), a.id);
    a.drive_token = 1;
  }
  const token = jwt.sign({ type: 'admin', id: a.id }, JWT_SECRET, { expiresIn: '8h' });
  return { token, name: a.name, driveConnected: !!a.drive_token };
}
router.get('/api/drive/callback', async (req, res) => {
  try {
    const st = jwt.verify(String(req.query.state || ''), JWT_SECRET);
    const { tokens } = await oauthClient().getToken(String(req.query.code || ''));
    if (st.g) {
      const data = await googleSignIn(tokens);
      const code = crypto.randomBytes(24).toString('hex');
      const now = Date.now();
      for (const [k, v] of gCodes) if (v.exp < now) gCodes.delete(k);
      gCodes.set(code, { exp: now + 60000, data });
      return res.redirect('/?gauth=' + code);
    }
    if (!tokens.refresh_token) return res.status(400).send('Google did not return a refresh token. Remove this app from your Google account permissions and try again.');
    db.prepare('UPDATE admins SET drive_token = ?, drive_folder = NULL WHERE id = ?').run(enc(tokens.refresh_token), st.id);
    res.redirect('/?drive=connected');
  } catch {
    res.status(400).send('Google connection failed. Please try again.');
  }
});
router.post('/api/drive/disconnect', auth('admin'), (req, res) => {
  db.prepare('UPDATE admins SET drive_token = NULL, drive_folder = NULL WHERE id = ?').run(req.adminId);
  res.json({ ok: true });
});

module.exports = router;

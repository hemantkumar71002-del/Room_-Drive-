const express = require('express');
const fs = require('fs');
const multer = require('multer');
const { Readable } = require('stream');
const { ALLOWED, MAX_BYTES } = require('../config');
const { db, listFiles } = require('../db');
const { auth } = require('../auth');
const { broadcast } = require('../realtime');
const { driveFor } = require('../services/drive');
const { PREVIEWABLE, previewPath, convertToPdf } = require('../services/preview');

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES },
  fileFilter: (req, file, cb) => {
    // multer 1.x reads names as latin1; restore UTF-8 so Hindi/other non-English file names are not garbled
    file.originalname = Buffer.from(file.originalname, 'latin1').toString('utf8');
    cb(null, ALLOWED.includes(file.originalname.split('.').pop().toLowerCase()));
  },
});

router.get('/api/files', auth('admin', 'user'), (req, res) => res.json(listFiles(req.adminId)));

router.post('/api/files', auth('admin', 'user'), upload.single('file'), async (req, res) => {
  if (req.type === 'user' && req.viewer.role !== 'uploader') return res.status(403).json({ error: 'You do not have permission to upload files.' });
  if (!req.file) return res.status(400).json({ error: 'No valid file received. Allowed types: ' + ALLOWED.join(', ').toUpperCase() + ' (max 25 MB).' });
  try {
    const d = await driveFor(req.adminId);
    if (!d) return res.status(409).json({ error: 'Google Drive is not connected.' });
    const f = req.file;
    const r = await d.drive.files.create({
      requestBody: { name: f.originalname, parents: [d.folder] },
      media: { mimeType: f.mimetype, body: Readable.from(f.buffer) },
      fields: 'id',
    });
    db.prepare('INSERT INTO files (admin_id, drive_file_id, name, ext, size, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)').run(
      req.adminId, r.data.id, f.originalname, f.originalname.split('.').pop().toLowerCase(), f.size,
      req.type === 'admin' ? 'admin' : req.viewer.username
    );
    broadcast(req.adminId);
    res.json({ ok: true });
  } catch (e) {
    console.error(e.message);
    res.status(502).json({ error: 'Upload to Google Drive failed.' });
  }
});

router.get('/api/files/:id/download', auth('admin', 'user'), async (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id = ? AND admin_id = ?').get(req.params.id, req.adminId);
  if (!f) return res.status(404).json({ error: 'File not found.' });
  try {
    const d = await driveFor(req.adminId);
    if (!d) return res.status(409).json({ error: 'Google Drive is not connected.' });
    const r = await d.drive.files.get({ fileId: f.drive_file_id, alt: 'media' }, { responseType: 'stream' });
    res.setHeader('Content-Disposition', "attachment; filename*=UTF-8''" + encodeURIComponent(f.name));
    r.data.on('error', () => res.destroy());
    r.data.pipe(res);
  } catch (e) {
    console.error(e.message);
    res.status(502).json({ error: 'Download from Google Drive failed.' });
  }
});

router.get('/api/files/:id/preview', auth('admin', 'user'), async (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id = ? AND admin_id = ?').get(req.params.id, req.adminId);
  if (!f) return res.status(404).json({ error: 'File not found.' });
  if (!PREVIEWABLE.includes(f.ext)) return res.status(400).json({ error: 'Preview is not available for this file type.' });
  try {
    const d = await driveFor(req.adminId);
    if (!d) return res.status(409).json({ error: 'Google Drive is not connected.' });
    const pdf = await convertToPdf(f, d);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline');
    fs.createReadStream(pdf).on('error', () => res.destroy()).pipe(res);
  } catch (e) {
    console.error(e.message);
    if (e.noOffice) return res.status(501).json({ error: 'Preview is not available on this server.' });
    res.status(502).json({ error: 'The preview could not be created.' });
  }
});

router.delete('/api/files/:id', auth('admin'), async (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id = ? AND admin_id = ?').get(req.params.id, req.adminId);
  if (!f) return res.status(404).json({ error: 'File not found.' });
  try {
    const d = await driveFor(req.adminId);
    if (d) await d.drive.files.delete({ fileId: f.drive_file_id }).catch(() => {});
  } catch (e) {
    console.error(e.message);
  }
  db.prepare('DELETE FROM files WHERE id = ?').run(f.id);
  fs.rm(previewPath(f), { force: true }, () => {});
  broadcast(req.adminId);
  res.json({ ok: true });
});

module.exports = router;

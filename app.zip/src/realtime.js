const { Server } = require('socket.io');
const { db, listFiles } = require('./db');
const { verify } = require('./auth');
const access = require('./access');

let io;
function initRealtime(server) {
  io = new Server(server, { cors: { origin: '*' } });
  io.use((socket, next) => {
    try {
      if (!access.socketOk(socket)) throw new Error('access');
      const ctx = verify(socket.handshake.auth.token || '');
      socket.join('a:' + ctx.adminId);
      if (ctx.viewer) socket.join('v:' + ctx.viewer.id);
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });
  return io;
}
const broadcast = (adminId) => io.to('a:' + adminId).emit('files:update', listFiles(adminId));
function kickViewer(id) {
  db.prepare('UPDATE viewers SET session_id = NULL, device_id = NULL WHERE id = ?').run(id);
  io.to('v:' + id).emit('force-logout');
  io.in('v:' + id).disconnectSockets(true);
}
module.exports = { initRealtime, broadcast, kickViewer };

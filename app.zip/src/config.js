require('dotenv').config();
const path = require('path');

const { JWT_SECRET } = process.env;
if (!JWT_SECRET) {
  console.error('Set JWT_SECRET in the environment.');
  process.exit(1);
}

module.exports = {
  JWT_SECRET,
  ALLOWED: ['pdf', 'doc', 'docx', 'pptx', 'png', 'jpg', 'jpeg'],
  MAX_BYTES: 25 * 1024 * 1024,
  PORT: process.env.PORT || 3000,
  PUBLIC_DIR: path.join(__dirname, '..', 'public'),
  DB_PATH: process.env.DB_PATH || 'app.db',
  PREVIEW_DIR: process.env.PREVIEW_DIR || 'previews',
  SOFFICE: process.env.SOFFICE_PATH || 'soffice',
};

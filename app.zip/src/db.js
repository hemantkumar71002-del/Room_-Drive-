const Database = require('better-sqlite3');
const { DB_PATH } = require('./config');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash TEXT NOT NULL,
  drive_token TEXT,
  drive_folder TEXT
);
CREATE TABLE IF NOT EXISTS viewers (
  id INTEGER PRIMARY KEY,
  admin_id INTEGER NOT NULL REFERENCES admins(id),
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('viewer','uploader')),
  status TEXT NOT NULL DEFAULT 'active',
  session_id TEXT,
  device_id TEXT
);
CREATE TABLE IF NOT EXISTS files (
  id INTEGER PRIMARY KEY,
  admin_id INTEGER NOT NULL REFERENCES admins(id),
  drive_file_id TEXT NOT NULL,
  name TEXT NOT NULL,
  ext TEXT NOT NULL,
  size INTEGER NOT NULL,
  uploaded_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);
for (const col of ['google_sub TEXT', 'email TEXT']) { try { db.exec('ALTER TABLE admins ADD COLUMN ' + col); } catch {} }
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS admins_google_sub ON admins(google_sub)');

const nameTaken = (n) =>
  db.prepare('SELECT 1 FROM admins WHERE name = ?').get(n) ||
  db.prepare('SELECT 1 FROM viewers WHERE username = ?').get(n);
const listFiles = (adminId) =>
  db.prepare('SELECT id, name, ext, size, uploaded_by, created_at FROM files WHERE admin_id = ? ORDER BY id DESC').all(adminId);

module.exports = { db, nameTaken, listFiles };

var ALLOWED = ['pdf','doc','docx','pptx','png','jpg','jpeg'], MAX_MB = 25;
var MIME = { pdf: 'application/pdf', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg' };
var $ = function(id){ return document.getElementById(id); };
var store = {
  get: function(k){ try { return localStorage.getItem(k); } catch (e) { return null; } },
  set: function(k, v){ try { localStorage.setItem(k, v); } catch (e) {} },
  del: function(k){ try { localStorage.removeItem(k); } catch (e) {} }
};
var DEV = store.get('rda_dev');
if (!DEV) {
  DEV = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Math.random()).slice(2) + String(Date.now());
  store.set('rda_dev', DEV);
}
var OT = null, S = null, socket = null, files = [], viewers = [], roleSel = 'user', curMode = 'login', filter = 'all', timer = null, previewUrl = null;

function esc(s){ return String(s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
var tt = null;
function setMsg(id, t, ok){ var e = $(id); e.textContent = t; e.className = 'msg' + (ok ? ' ok' : '');
  if (id === 'tm') { var w = $('toastw'); w.className = 'toast' + (t ? '' : ' hidden'); clearTimeout(tt); if (t && t.indexOf('Uploading') < 0) tt = setTimeout(function(){ w.className = 'toast hidden'; }, 5000); } }
function fmt(b){ return b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; }
function grp(e){ return e === 'png' || e === 'jpg' || e === 'jpeg' ? 'image' : (e === 'pdf' ? 'pdf' : 'doc'); }
function show(id){
  ['gate','auth','ownerIn','pgOwner','admin','viewer','pgUsers'].forEach(function(s){ $(s).className = s === id ? '' : 'hidden'; });
  $('fab').className = (S && (id === 'admin' || id === 'viewer')) ? 'fab' : 'fab hidden';
  if (id === 'auth') $('toastw').className = 'toast hidden';
  window.scrollTo(0, 0);
}
function emsg(e){ return e.name === 'TypeError' ? 'Cannot reach the server. Please try again.' : e.message; }

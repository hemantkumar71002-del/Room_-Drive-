// ----- Files -----
function loadFiles(){
  call('/api/files').then(function(l){ files = l; renderFiles(); }).catch(function(){});
}
function renderFiles(){ if (!S) return; if (S.type === 'admin') renderAdminFiles(); else drawV(); }
function fileById(id){ for (var i = 0; i < files.length; i++) if (files[i].id === id) return files[i]; return null; }
function renderAdminFiles(){
  var q = $('qa').value.trim().toLowerCase();
  var shown = files.filter(function(f){ return f.name.toLowerCase().indexOf(q) >= 0; });
  $('flist').innerHTML = shown.length ? shown.map(function(f){
    return '<div class="row"><div><span class="name">' + esc(f.name) + '</span><span class="pill">' + esc(f.ext.toUpperCase()) + '</span>' +
      '<div class="meta">' + fmt(f.size) + ' &middot; uploaded by ' + esc(f.uploaded_by) + '</div></div>' +
      '<div class="acts"><button class="sm" onclick="openF(' + f.id + ')">Open</button>' +
      '<button class="sm" onclick="download(' + f.id + ')">Download</button>' +
      '<button class="sm d" onclick="delFile(' + f.id + ')">Delete</button></div></div>';
  }).join('') : '<div class="empty">' + (files.length ? 'No files found.' : 'No documents yet. Tap + to upload.') + '</div>';
}
function setF(f){ filter = f; drawV(); }
function drawV(){
  var q = $('q').value.trim().toLowerCase();
  var shown = files.filter(function(f){ return (filter === 'all' || grp(f.ext) === filter) && f.name.toLowerCase().indexOf(q) >= 0; });
  $('vfiles').innerHTML = shown.length ? shown.map(function(f){
    return '<div class="row"><div><span class="name">' + esc(f.name) + '</span>' +
      '<span class="pill">' + esc(f.ext.toUpperCase()) + '</span><div class="meta">' + fmt(f.size) + '</div></div>' +
      '<div class="acts"><button class="sm" onclick="openF(' + f.id + ')">Open</button><button class="sm" onclick="download(' + f.id + ')">Download</button></div></div>';
  }).join('') : '<div class="empty">No files found.</div>';
}
function fetchBlob(id, kind){
  return api('/api/files/' + id + '/' + (kind || 'download')).then(function(r){
    if (r.ok) return r.blob();
    return r.json().catch(function(){ return {}; }).then(function(d){
      var e = new Error(d.error || 'The download failed.'); e.status = r.status; throw e;
    });
  });
}
function download(id){
  var f = fileById(id); if (!f) return;
  fetchBlob(id).then(function(b){
    var u = URL.createObjectURL(b), a = document.createElement('a');
    a.href = u; a.download = f.name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function(){ URL.revokeObjectURL(u); }, 1500);
  }).catch(function(e){ if (e.message !== 'session') alert(emsg(e)); });
}
function previewBox(){ return $(S.type === 'admin' ? 'prevA' : 'prev'); }
function closePreview(){
  if (previewUrl) { URL.revokeObjectURL(previewUrl); previewUrl = null; }
  ['prev','prevA'].forEach(function(id){ $(id).className = 'prev hidden'; $(id).innerHTML = ''; });
}
function openF(id){
  var f = fileById(id); if (!f) return;
  var isDoc = grp(f.ext) === 'doc', isImg = grp(f.ext) === 'image';
  closePreview();
  var p = previewBox();
  p.className = 'prev';
  p.innerHTML = '<div class="meta">' + (isDoc ? 'Preparing preview. The first time can take a few seconds&hellip;' : 'Loading preview&hellip;') + '</div>';
  fetchBlob(id, isDoc ? 'preview' : 'download').then(function(b){
    previewUrl = URL.createObjectURL(new Blob([b], { type: isDoc ? 'application/pdf' : MIME[f.ext] }));
    p.innerHTML = (isImg
      ? '<img alt="' + esc(f.name) + '" src="' + previewUrl + '">'
      : '<iframe title="' + esc(f.name) + '" src="' + previewUrl + '"></iframe>') +
      '<p>' + (isImg ? '' : '<button class="sm" onclick="window.open(previewUrl)">Open in new tab</button> ') +
      '<button class="sm" onclick="closePreview()">Close</button></p>';
    p.scrollIntoView({ block: 'nearest' });
  }).catch(function(e){
    if (e.message === 'session') return;
    if (isDoc && e.status === 501) { closePreview(); return download(id); }
    p.innerHTML = '<div class="msg">' + esc(emsg(e)) + '</div>';
  });
}
function delFile(id){
  var f = fileById(id); if (!f) return;
  if (!confirm('Delete ' + f.name + '?')) return;
  call('/api/files/' + id, { method: 'DELETE' }).then(loadFiles).catch(fail('tm'));
}
function upload(inId, msgId){
  if (S.type === 'user' && S.role !== 'uploader') return setMsg(msgId, 'Your account is view-only. Ask the administrator to give you the Uploader role.');
  var list = Array.prototype.slice.call($(inId).files);
  if (!list.length) return setMsg(msgId, 'No file selected.');
  var bad = [], ok = 0;
  setMsg(msgId, 'Uploading\u2026', true);
  (function next(){
    var f = list.shift();
    if (!f) {
      $(inId).value = '';
      loadFiles();
      if (bad.length) setMsg(msgId, 'These files were not uploaded: ' + bad.join(', '));
      else setMsg(msgId, ok + (ok === 1 ? ' file' : ' files') + ' uploaded.', true);
      return;
    }
    var ext = f.name.split('.').pop().toLowerCase();
    if (ALLOWED.indexOf(ext) < 0) { bad.push(f.name + ' (file type not allowed)'); return next(); }
    if (f.size > MAX_MB * 1048576) { bad.push(f.name + ' (larger than ' + MAX_MB + ' MB)'); return next(); }
    var fd = new FormData(); fd.append('file', f);
    api('/api/files', { method: 'POST', body: fd }).then(function(r){
      return r.json().catch(function(){ return {}; }).then(function(d){
        if (r.ok) ok++; else bad.push(f.name + ' (' + (d.error || 'failed') + ')');
        next();
      });
    }).catch(function(e){
      if (e.message === 'session') return;
      bad.push(f.name + ' (network error)'); next();
    });
  })();
}

// ----- Google Drive -----
function goExternal(u){ window.location.href = u; }
function googleReturn(code){
  return call('/api/auth/google/exchange', { method: 'POST', json: { code: code } }).then(function(d){
    roleSel = 'admin';
    S = { type: 'admin', token: d.token, name: d.name, drive: d.driveConnected };
    store.set('rda_token', S.token); store.set('rda_type', 'admin'); store.set('rda_name', S.name); store.set('rda_role', '');
    enter();
    setMsg('tm', d.driveConnected ? 'Signed in with Google. Google Drive is connected.' : 'Signed in with Google.', true);
  }).catch(function(e){ pick('admin'); setMsg('am', e.message); });
}
function backHome(){ show(S && S.type === 'admin' ? 'admin' : 'viewer'); }
function renderDrive(){
  if (!S) return;
  $('dst').textContent = S.drive ? 'Connected' : 'Not connected';
  $('dst').className = 'pill' + (S.drive ? ' on' : '');
  $('dform').className = S.drive ? 'hidden' : '';
  $('db').className = S.drive ? 'sm d' : 'sm d hidden';
}
function driveGo(noEmail){
  if (!S || S.type !== 'admin') return setMsg('dm', 'Please log in as admin first.');
  var em = noEmail ? '' : $('dem').value.trim();
  if (!noEmail && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) return setMsg('dm', 'Please enter a valid Google email ID.');
  setMsg('dm', '');
  call('/api/drive/connect' + (em ? '?email=' + encodeURIComponent(em) : '')).then(function(d){ goExternal(d.url); }).catch(fail('dm'));
}
function toggleDrive(){
  if (!S || S.type !== 'admin') return;
  setMsg('dm', '');
  if (S.drive) {
    if (!confirm('Disconnect Google Drive? Existing files stay in Drive, but they cannot be opened here until you reconnect.')) return;
    call('/api/drive/disconnect', { method: 'POST' }).then(function(){ S.drive = false; renderDrive(); }).catch(fail('dm'));
  } else {
    call('/api/drive/connect').then(function(d){ goExternal(d.url); }).catch(fail('dm'));
  }
}

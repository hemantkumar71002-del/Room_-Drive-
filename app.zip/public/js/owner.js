// ----- Owner panel: saare admin aur user accounts ka control -----
function ownerPage(){ $('opw').value = ''; setMsg('om', ''); show('ownerIn'); }
function ownerGo(){
  var p = $('opw').value;
  if (!p) return setMsg('om', 'Enter the owner password.');
  $('obtn').disabled = true;
  call('/api/owner/login', { method: 'POST', json: { password: p } }).then(function(d){
    OT = d.token; $('opw').value = ''; setMsg('ol', ''); show('pgOwner'); ownerLoad();
  }).catch(fail('om')).then(function(){ $('obtn').disabled = false; });
}
function ownerOut(msg){
  OT = null; owners = []; opened = {};
  pick('user');
  if (msg) setMsg('am', msg, true);
}
var owners = [], opened = {}, oviewers = {};
function ownerLoad(){
  call('/api/owner/overview').then(function(d){
    owners = d.admins; signupOpen = d.signupOpen;
    $('osg').textContent = d.signupOpen ? 'Open' : 'Closed';
    $('osg').className = 'pill' + (d.signupOpen ? ' on' : '');
    $('osb').textContent = d.signupOpen ? 'Close signups' : 'Open signups';
    ownerDraw();
  }).catch(fail('ol'));
}
function ownerSignup(){
  call('/api/owner/signup', { method: 'POST', json: { open: !signupOpen } }).then(ownerLoad).catch(fail('ol'));
}
function ownerDraw(){
  $('olist').innerHTML = owners.map(function(a){
    var open = opened[a.id];
    return '<div class="row"><div><span class="name">' + esc(a.name) + '</span>' +
      (a.blocked ? '<span class="pill" style="color:var(--danger);border-color:var(--danger)">Blocked</span>' : '') +
      '<div class="meta">' + a.viewers + ' users &middot; ' + a.files + ' files &middot; ' + fmt(a.bytes) + '</div></div>' +
      '<div class="acts"><button class="sm" onclick="ownerUsers(' + a.id + ')">' + (open ? 'Hide users' : 'Users') + '</button>' +
      '<button class="sm" onclick="ownerResetAdmin(' + a.id + ')">Reset password</button>' +
      '<button class="sm" onclick="ownerBlock(' + a.id + ',' + (a.blocked ? 0 : 1) + ')">' + (a.blocked ? 'Unblock' : 'Block') + '</button>' +
      '<button class="sm d" onclick="ownerDelAdmin(' + a.id + ')">Delete</button></div></div>' +
      (open ? '<div style="padding:0 0 10px 14px;border-bottom:1px solid var(--line)">' + ownerViewersHtml(a.id) + '</div>' : '');
  }).join('') || '<div class="empty">No admin accounts yet.</div>';
}
function ownerViewersHtml(aid){
  var l = oviewers[aid] || [];
  return l.map(function(v){
    return '<div class="row"><div><span class="name">' + esc(v.username) + '</span><span class="pill">' + (v.role === 'uploader' ? 'Uploader' : 'Viewer') + '</span>' +
      '<span class="pill ' + (v.online ? 'on' : '') + '">' + (v.online ? 'Logged in' : 'Device free') + '</span></div>' +
      '<div class="acts"><button class="sm" onclick="ownerResetViewer(' + aid + ',' + v.id + ')">Reset password</button>' +
      '<button class="sm" onclick="ownerKick(' + aid + ',' + v.id + ')">Force logout</button>' +
      '<button class="sm d" onclick="ownerDelViewer(' + aid + ',' + v.id + ')">Remove</button></div></div>';
  }).join('') || '<div class="empty">No users under this admin.</div>';
}
function ownerUsers(aid){
  if (opened[aid]) { opened[aid] = false; return ownerDraw(); }
  call('/api/owner/admins/' + aid + '/viewers').then(function(l){ oviewers[aid] = l; opened[aid] = true; ownerDraw(); }).catch(fail('ol'));
}
function ownerRefresh(aid){
  call('/api/owner/admins/' + aid + '/viewers').then(function(l){ oviewers[aid] = l; ownerLoad(); }).catch(fail('ol'));
}
function ownerPw(){ var p = prompt('New password (minimum 6 characters):'); if (p === null) return null; if (p.length < 6) { alert('The password is too short.'); return null; } return p; }
function ownerResetAdmin(id){
  var p = ownerPw(); if (!p) return;
  call('/api/owner/admins/' + id + '/reset-password', { method: 'POST', json: { password: p } }).then(function(){ setMsg('ol', 'Admin password updated.', true); }).catch(fail('ol'));
}
function ownerBlock(id, b){
  call('/api/owner/admins/' + id + '/block', { method: 'POST', json: { blocked: !!b } }).then(function(){ setMsg('ol', b ? 'Admin blocked. All their users were logged out.' : 'Admin unblocked.', true); ownerLoad(); }).catch(fail('ol'));
}
function ownerDelAdmin(id){
  if (!confirm('Delete this admin with ALL their users and files? This cannot be undone.')) return;
  call('/api/owner/admins/' + id, { method: 'DELETE' }).then(function(){ setMsg('ol', 'Admin deleted.', true); ownerLoad(); }).catch(fail('ol'));
}
function ownerResetViewer(aid, id){
  var p = ownerPw(); if (!p) return;
  call('/api/owner/viewers/' + id + '/reset-password', { method: 'POST', json: { password: p } }).then(function(){ setMsg('ol', 'User password updated.', true); ownerRefresh(aid); }).catch(fail('ol'));
}
function ownerKick(aid, id){ call('/api/owner/viewers/' + id + '/force-logout', { method: 'POST' }).then(function(){ ownerRefresh(aid); }).catch(fail('ol')); }
function ownerDelViewer(aid, id){
  if (!confirm('Remove this user?')) return;
  call('/api/owner/viewers/' + id, { method: 'DELETE' }).then(function(){ ownerRefresh(aid); }).catch(fail('ol'));
}

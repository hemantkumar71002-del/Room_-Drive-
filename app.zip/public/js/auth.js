// ----- Login screens -----
function mode(m){
  curMode = m;
  var adm = roleSel === 'admin';
  $('tabs').className = adm ? 'tabs' : 'hidden';
  $('tCreate').style.display = signupOpen ? '' : 'none';
  $('tLogin').setAttribute('aria-selected', m === 'login');
  $('tCreate').setAttribute('aria-selected', m === 'create');
  $('cw').className = m === 'create' ? '' : 'hidden';
  $('at').textContent = adm ? 'Admin' : 'User';
  $('anl').textContent = adm ? 'Admin name' : 'User ID';
  $('toAdmin').className = adm ? 'swap hidden' : 'swap';
  $('toUser').className = adm ? 'swap' : 'swap hidden';
  $('ab').textContent = m === 'create' ? 'Create admin ID' : 'Login';
  setMsg('am', '');
}
var signupOpen = true;
function loadSignup(){
  fetch((window.SERVER_URL || '') + '/api/signup-status', { headers: { 'x-access-code': store.get('rda_ac') || '' } })
    .then(function(r){ return r.json(); }).then(function(d){ signupOpen = d.open !== false; mode(curMode); }).catch(function(){});
}
function pick(r){
  roleSel = r;
  $('an').value = ''; $('ap').value = ''; $('ap2').value = '';
  mode('login');
  show('auth');
}
function authGo(){
  var n = $('an').value.trim(), p = $('ap').value, btn = $('ab');
  if (curMode === 'create') {
    if (!n || !p) return setMsg('am', 'Please enter both the admin name and the password.');
    if (p.length < 6) return setMsg('am', 'The password must contain at least 6 characters.');
    if (p !== $('ap2').value) return setMsg('am', 'The two passwords do not match.');
    btn.disabled = true;
    return call('/api/admin/register', { method: 'POST', json: { name: n, password: p } }).then(function(){
      mode('login'); $('ap').value = ''; $('ap2').value = '';
      setMsg('am', 'Admin account created. Please log in.', true);
    }).catch(fail('am')).then(function(){ btn.disabled = false; });
  }
  if (!n || !p) return setMsg('am', roleSel === 'admin' ? 'Please enter both the admin name and the password.' : 'Please enter both the user ID and the password.');
  btn.disabled = true;
  var req = roleSel === 'admin'
    ? call('/api/admin/login', { method: 'POST', json: { name: n, password: p } })
    : call('/api/user/login', { method: 'POST', json: { username: n, password: p, deviceId: DEV } });
  req.then(function(d){
    $('ap').value = '';
    S = roleSel === 'admin'
      ? { type: 'admin', token: d.token, name: d.name }
      : { type: 'user', token: d.token, name: d.username, role: d.role };
    store.set('rda_token', S.token); store.set('rda_type', S.type); store.set('rda_name', S.name); store.set('rda_role', S.role || '');
    enter();
  }).catch(fail('am')).then(function(){ btn.disabled = false; });
}

// ----- Session -----
function enter(){
  if (S.type === 'admin') {
    $('hello').textContent = S.name;
    show('admin');
    loadViewers();
    clearInterval(timer);
    timer = setInterval(loadViewers, 15000);
  } else {
    $('who').textContent = S.name;
    $('role').textContent = S.role === 'uploader' ? 'Uploader: can view and upload files' : 'Viewer: view only';
        $('q').value = ''; filter = 'all';
    show('viewer');
  }
  closePreview();
  loadFiles();
  connectSocket();
}
function connectSocket(){
  if (socket) socket.disconnect();
  socket = io(window.SERVER_URL || undefined, { auth: { token: S.token, code: store.get('rda_ac') || '' } });
  socket.on('files:update', function(list){ files = list; renderFiles(); });
  socket.on('force-logout', function(){
    endSession(S && S.type === 'user' ? 'Your access has ended. Please contact the administrator.' : 'Your session has ended.');
  });
  socket.on('connect_error', function(err){
    if (err && err.message === 'unauthorized') endSession('Your session has ended. Please log in again.');
    else if (err && err.message === 'access') { store.del('rda_ac'); gateShow('Access password changed. Enter it again.'); }
  });
}
function endSession(msg){
  if (!S) return;
  var type = S.type;
  S = null;
  ['rda_token','rda_type','rda_name','rda_role'].forEach(function(k){ store.del(k); });
  if (socket) { socket.disconnect(); socket = null; }
  clearInterval(timer);
  toggleMenu(false);
  closePreview();
  files = []; viewers = [];
  pick(type);
  if (msg) setMsg('am', msg, true);
}
function logout(){
  if (!S) return;
  if (S.type === 'user') fetch((window.SERVER_URL || '') + '/api/user/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + S.token, 'x-access-code': store.get('rda_ac') || '' } }).catch(function(){});
  endSession('You have been logged out.');
}
function toggleMenu(f){
  var m = $('menu'), b = $('burger');
  if (!m || !b) return;
  var open = typeof f === 'boolean' ? f : m.className.indexOf('hidden') >= 0;
  m.className = open ? 'menu' : 'menu hidden';
  b.setAttribute('aria-expanded', open ? 'true' : 'false');
}
function go(id){ toggleMenu(false); $(id).scrollIntoView({ block: 'start' }); }
document.addEventListener('click', function(e){
  var m = $('menu'), b = $('burger');
  if (!m || !b) return;
  if (!m.contains(e.target) && !b.contains(e.target)) toggleMenu(false);
});

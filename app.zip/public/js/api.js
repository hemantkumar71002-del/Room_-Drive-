// ----- API helpers -----
function api(path, opts){
  opts = opts || {};
  var h = opts.headers || {};
  if (S) h.Authorization = 'Bearer ' + S.token;
  if (opts.json) { h['Content-Type'] = 'application/json'; opts.body = JSON.stringify(opts.json); }
  opts.headers = h;
  return fetch((window.SERVER_URL || '') + path, opts).then(function(r){
    if (r.status === 401 && S) { endSession('Your session has ended. Please log in again.'); throw new Error('session'); }
    return r;
  });
}
function call(path, opts){
  return api(path, opts).then(function(r){
    return r.json().catch(function(){ return {}; }).then(function(d){
      if (!r.ok) throw new Error(d.error || 'The request failed.');
      return d;
    });
  });
}
function fail(id){ return function(e){ if (e.message !== 'session') setMsg(id, emsg(e)); }; }

// ----- API helpers -----
function api(path, opts){
  opts = opts || {};
  var h = opts.headers || {};
  h['x-access-code'] = store.get('rda_ac') || '';
  if (S) h.Authorization = 'Bearer ' + S.token;
  else if (OT) h.Authorization = 'Bearer ' + OT;
  if (opts.json) { h['Content-Type'] = 'application/json'; opts.body = JSON.stringify(opts.json); }
  opts.headers = h;
  return fetch((window.SERVER_URL || '') + path, opts).then(function(r){
    if (r.status === 403) { return r.clone().json().catch(function(){ return {}; }).then(function(d){
      if (d && d.access) { store.del('rda_ac'); gateShow('Access password changed. Enter it again.'); throw new Error('session'); }
      return r;
    }); }
    if (r.status === 401 && OT && !S) { ownerOut('Owner session ended. Please log in again.'); throw new Error('session'); }
    if (r.status === 401 && S) { endSession('Your session has ended. Please log in again.'); throw new Error('session'); }
    return r;
  });
}
function call(path, opts){
  return api(path, opts).then(function(r){
    return r.json().catch(function(){ return {}; }).then(function(d){
      if (!r.ok) throw new Error(d.error || 'The request failed.');
      return d;
    });
  });
}
function fail(id){ return function(e){ if (e.message !== 'session') setMsg(id, emsg(e)); }; }

// ----- Access password gate -----
function gateShow(msg){
  if (S) { S = null; if (socket) { socket.disconnect(); socket = null; } clearInterval(timer); }
  show('gate');
  setMsg('gm', msg || '', false);
  var i = $('gcode'); if (i) { i.value = ''; }
}
function gateCheck(code){
  return fetch((window.SERVER_URL || '') + '/api/access-check', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: code })
  }).then(function(r){ return r.json().catch(function(){ return {}; }).then(function(d){ d.status = r.status; return d; }); });
}
function gateGo(){
  var code = $('gcode').value;
  if (!code) return setMsg('gm', 'Enter the access password.');
  $('gbtn').disabled = true;
  gateCheck(code).then(function(d){
    $('gbtn').disabled = false;
    if (d.ok) { store.set('rda_ac', code); setMsg('gm', ''); startApp(); }
    else setMsg('gm', d.error || 'Wrong access password.');
  }).catch(function(e){ $('gbtn').disabled = false; setMsg('gm', emsg(e)); });
}

// ----- Start: restore a saved session, or show the user login -----
(function(){
  var qs = new URLSearchParams(location.search), gcode = qs.get('gauth'), drv = qs.get('drive') === 'connected';
  if (gcode) { history.replaceState(null, '', location.pathname); return googleReturn(gcode); }
  var t = store.get('rda_token'), ty = store.get('rda_type');
  if (drv) history.replaceState(null, '', location.pathname);
  if (!t || !ty) return pick('user');
  S = { type: ty, token: t, name: store.get('rda_name') || '', role: store.get('rda_role') || 'viewer', drive: false };
  var ready = ty === 'admin'
    ? call('/api/admin/me').then(function(d){ S.name = d.name; S.drive = d.driveConnected; })
    : call('/api/files').then(function(l){ files = l; });
  ready.then(function(){
    enter();
    if (drv && S && S.type === 'admin') {
      setMsg('tm', 'Google Drive connected.', true);
      openDrive();
    }
  }).catch(function(){ if (S) { S = null; pick(ty); } });
})();

// ----- Start: restore a saved session, or show the user login -----
function startApp(){
  loadSignup();
  var t = store.get('rda_token'), ty = store.get('rda_type');
  if (!t || !ty) return pick('user');
  S = { type: ty, token: t, name: store.get('rda_name') || '', role: store.get('rda_role') || 'viewer' };
  var ready = ty === 'admin'
    ? call('/api/admin/me').then(function(d){ S.name = d.name; })
    : call('/api/files').then(function(l){ files = l; });
  ready.then(function(){
    enter();
  }).catch(function(){ if (S) { S = null; pick(ty); } });
}
// Pehle access password check; sahi ho (ya server par laga hi na ho) tabhi app khule.
gateCheck(store.get('rda_ac') || '').then(function(d){
  if (d.ok) startApp(); else gateShow('');
}).catch(function(){ startApp(); });

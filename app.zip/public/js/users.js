// ----- Viewers (admin) -----
function loadViewers(){
  call('/api/admin/viewers').then(function(l){ viewers = l; renderViewers(); }).catch(function(){});
}
function renderViewers(){
  $('vlist').innerHTML = viewers.map(function(v){
    return '<div class="row"><div><span class="name">' + esc(v.username) + '</span>' +
      '<span class="pill">' + (v.role === 'uploader' ? 'Uploader' : 'Viewer') + '</span>' +
      '<span class="pill ' + (v.online ? 'on' : '') + '">' + (v.online ? 'Logged in on a device' : 'Device free') + '</span>' +
      '<div class="meta">One ID can be logged in on one device only.</div></div>' +
      '<div class="acts"><button class="sm" onclick="resetPass(' + v.id + ')">Reset password</button>' +
      '<button class="sm" onclick="forceLogout(' + v.id + ')">Force logout</button>' +
      '<button class="sm d" onclick="removeViewer(' + v.id + ')">Remove</button></div></div>';
  }).join('') || '<div class="empty">There are no viewers yet. Open the menu and choose New user.</div>';
}
function vName(id){ for (var i = 0; i < viewers.length; i++) if (viewers[i].id === id) return viewers[i].username; return ''; }
function openNew(){ toggleMenu(false); setMsg('vm', ''); $('nu').className = 'modal'; $('vn').focus(); }
function closeNew(){ closeM('nu'); }
function closeM(id){ $(id).className = 'modal hidden'; }
function openUsers(){ toggleMenu(false); setMsg('vl', ''); show('pgUsers'); }
function openDrive(){
  toggleMenu(false);
  if (!S || S.type !== 'admin') return;
  setMsg('dm', '');
  renderDrive();
  show('pgDrive');
}
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeM('nu'); });
function addViewer(){
  var n = $('vn').value.trim(), p = $('vp').value;
  if (!n || !p) return setMsg('vm', 'Please enter both the viewer name and the password.');
  if (p.length < 6) return setMsg('vm', 'The password must contain at least 6 characters.');
  call('/api/admin/viewers', { method: 'POST', json: { username: n, password: p, role: $('vr').value } }).then(function(){
    $('vn').value = ''; $('vp').value = '';
    setMsg('vm', 'User created. Please share this name and password with the user.', true);
    loadViewers();
  }).catch(fail('vm'));
}
function removeViewer(id){
  if (!confirm('Remove ' + vName(id) + '? Their device will be logged out immediately.')) return;
  call('/api/admin/viewers/' + id, { method: 'DELETE' }).then(loadViewers).catch(fail('vl'));
}
function forceLogout(id){
  call('/api/admin/viewers/' + id + '/force-logout', { method: 'POST' }).then(loadViewers).catch(fail('vl'));
}
function resetPass(id){
  var np = prompt('New password (minimum 6 characters):');
  if (np === null) return;
  if (np.length < 6) return alert('The password is too short.');
  call('/api/admin/viewers/' + id + '/reset-password', { method: 'POST', json: { password: np } })
    .then(function(){ setMsg('vl', 'Password updated and the device was logged out.', true); loadViewers(); }).catch(fail('vl'));
}

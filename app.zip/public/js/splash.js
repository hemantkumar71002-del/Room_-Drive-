// ----- Splash screen (shown on every launch, before login) -----
(function(){
  var sp = document.getElementById('splash'), done = false;
  function hide(){ if (done) return; done = true; sp.className = 'out'; setTimeout(function(){ if (sp.parentNode) sp.parentNode.removeChild(sp); }, 700); }
  sp.addEventListener('click', hide);
  setTimeout(hide, 3000);
})();


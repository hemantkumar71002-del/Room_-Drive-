// ===== SIRF YAHI EK LINE BADALNI HAI =====
// Apne hosted backend ka poora URL (https://...), end mein "/" nahi.
// Web version (server se khulne wala) mein ise '' (khali) rakhein.
window.SERVER_URL = '';
if (window.SERVER_URL) document.write('<script src="' + window.SERVER_URL + '/socket.io/socket.io.js"><\/script>');
else document.write('<script src="/socket.io/socket.io.js"><\/script>');

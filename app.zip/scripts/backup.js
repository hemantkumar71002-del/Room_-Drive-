// Makes a safe copy of the SQLite database. Run: npm run backup
// Schedule it daily (cron, or your host's scheduled job).
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const dbPath = process.env.DB_PATH || 'app.db';
const dir = process.env.BACKUP_DIR || 'backups';
const keep = Number(process.env.BACKUP_KEEP) || 30;

fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const dest = path.join(dir, 'app-' + stamp + '.db');

const db = new Database(dbPath, { readonly: true, fileMustExist: true });
db.backup(dest)
  .then(() => {
    db.close();
    const old = fs.readdirSync(dir).filter((f) => /^app-.*\.db$/.test(f)).sort();
    old.slice(0, Math.max(0, old.length - keep)).forEach((f) => fs.unlinkSync(path.join(dir, f)));
    console.log('Backup saved: ' + dest);
  })
  .catch((e) => {
    console.error('Backup failed: ' + e.message);
    process.exit(1);
  });

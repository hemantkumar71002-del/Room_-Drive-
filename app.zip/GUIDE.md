# Room Drive App: Final Guide (Local test, Hosting, Google verification)

## Folder structure

```
room-drive-app/
  server.js  package.json
  .env.example  Dockerfile  .dockerignore
  README.md  GUIDE.md
  scripts/backup.js
  src/
    config.js  crypto.js  db.js  auth.js  realtime.js
    routes/    admin.js  viewers.js  user.js  google.js  files.js
    services/  drive.js  preview.js
  public/
    index.html  sw.js  manifest.json  bg.jpg  icons...
    css/style.css
    js/        core.js  api.js  auth.js  drive.js  users.js  files.js  main.js  splash.js
```

---

## Part 1: Local test (apne computer par)

1. **Node.js 20 ya naya** install karein. (DOC/PPTX preview test karna ho to **LibreOffice** bhi install karein. Na ho to bas download chalega.)
2. Project folder mein terminal kholein: `npm install`
   - Windows par `better-sqlite3` error de to "Visual Studio Build Tools" (C++) install karke dobara try karein.
3. `.env.example` ki copy banakar naam `.env` rakhein. Do secret banayein:
   - `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` chalakar output `ENCRYPTION_KEY` mein daalein.
   - Dobara chalakar naya output `JWT_SECRET` mein daalein.
4. **Google Cloud Console** (console.cloud.google.com):
   1. Naya project banayein.
   2. APIs & Services > Library > **Google Drive API** > Enable.
   3. OAuth consent screen (ab "Google Auth Platform": Branding, Audience, Data Access):
      - User type: **External**
      - Data Access mein scope add karein: `https://www.googleapis.com/auth/drive.file`
      - Audience mein apna Google account **Test user** ke taur par jodein.
   4. Credentials > Create credentials > **OAuth client ID** > type **Web application**.
      - Authorized redirect URI: `http://localhost:3000/api/drive/callback`
   5. Client ID aur secret `.env` mein `GOOGLE_CLIENT_ID` aur `GOOGLE_CLIENT_SECRET` mein daalein.
5. `npm start`, phir browser mein `http://localhost:3000` kholein.

### Test checklist

- [ ] Admin tab > "Create Admin ID" se admin banayein, phir login karein
- [ ] Menu > Google Drive > **Connect Drive**, Google sign-in poora karein, "Connected" dikhna chahiye
- [ ] PDF, PNG aur DOCX/PPTX upload karein. Drive mein "Room Drive App" folder banna chahiye
- [ ] Open aur Download dono dekhein (DOCX/PPTX ka preview pehli baar thoda der lega)
- [ ] Ek Viewer aur ek Uploader banayein
- [ ] Viewer se login karke file dekhein. Viewer ko upload box nahi dikhna chahiye
- [ ] Doosre browser ya phone se wahi ID chalayein. Error aana chahiye ("already in use on another device")
- [ ] Admin se **Force logout** dabayein. Viewer ka device turant logout hona chahiye
- [ ] Admin upload kare to viewer ki list bina refresh ke badalni chahiye
- [ ] `npm run backup` chalayein. `backups/` mein file banni chahiye

Agar "Google did not return a refresh token" aaye: myaccount.google.com/permissions se app hata dein aur dobara Connect karein.

---

## Part 2: Hosting (online daalna)

Chahiye: **Docker chalane wala host** (taaki LibreOffice aa sake), **persistent disk**, aur HTTPS (zyadatar hosts khud dete hain).

1. Code ko GitHub par daalein. `.env` aur `app.db` kabhi commit na karein (`.dockerignore` unhe image se bahar rakhta hai).
2. Host par Docker se deploy karein (Dockerfile maujood hai).
3. **Persistent disk** `/data` par mount karein.
4. Host ki Environment settings mein ye daalein:

| Naam | Value |
|---|---|
| `JWT_SECRET`, `ENCRYPTION_KEY` | wahi jo `.env` mein hain (ya naye) |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Google se |
| `GOOGLE_REDIRECT_URI` | `https://aapka-domain/api/drive/callback` |
| `DB_PATH` | `/data/app.db` |
| `PREVIEW_DIR` | `/data/previews` |
| `BACKUP_DIR` | `/data/backups` |
| `TRUST_PROXY` | `1` |
| `BACKUP_KEEP` | `30` |

5. Google Console mein OAuth client ke **Authorized redirect URIs** mein ye naya `https://.../api/drive/callback` jodein.
6. Sirf **ek instance** chalayein (SQLite aur live updates ek hi server par chalte hain).
7. **Backup:** host ka scheduled job / cron roz `npm run backup` chalaye. Backup ki copy server ke bahar bhi rakhein, aur `ENCRYPTION_KEY` alag jagah safe rakhein. Ye key khoi to har admin ko Drive dobara connect karna padega.
8. Chhote free plans par LibreOffice ko kaafi RAM lagti hai. Preview na chale to bada plan lein.

---

## Part 3: Google verification

- App sirf `drive.file` scope maangti hai. Google ke docs ise **non-sensitive** batate hain: sirf basic verification lagti hai, restricted scopes wali bhaari security assessment (CASA) nahi.
- **Testing mode ki dikkat:** sirf test users connect kar sakte hain (limit 100) aur Drive token **7 din mein expire** hota hai. Roz ke use ke liye app ko **"In production"** mein daalna zaroori hai.

Steps:
1. Ek simple **homepage** aur **privacy policy** page banayein (jisme likha ho ki Drive ka data sirf file upload/download ke liye use hota hai).
2. Apna **domain** Google Search Console mein verify karein, aur use Google Auth Platform ke Branding mein jodein (app ka naam, logo, homepage, privacy policy link).
3. Audience mein **Publish app** dabayein.
4. Agar Google verification maange (Verification Center mein dikhega), to wahin se submit karein aur email ke sawalon ka jawab dein. Aam taur par `drive.file` ke liye bas ye batana hota hai ki app sirf apni banai hui files use karti hai.

Google ke niyam aur screens badalte rehte hain, isliye final step par console mein jo dikhe use hi maanein.

# Quick guide
1. Put this code on GitHub and deploy it on Render (Docker).
2. Set the environment variables listed in README.md.
3. Open the Render URL. Enter the access password, then create an admin ID.
4. Use "Owner login" (on the login screen) with OWNER_PASSWORD to manage every admin and user.
5. Put the Render URL in `config.js` (SERVER_URL) of the APK package and build the APK.
